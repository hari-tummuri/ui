import streamlit as st
from streamlit_option_menu import option_menu

# #As a side bar
# # with st.sidebar:
# #     selected=option_menu(
# #         menu_title="Home", #mandatory required
# #         options=["Page1","Page 2"], 
# #         icons=["house","book"],#optional
# #         menu_icon=["cast"],
# #         default_index=0,
# #     )

# #horizontal bar

st.title("Legal App")
st.markdown(
        """
        <style>
            .title {
                background-image: url('C:/Users/Kodee/Desktop/webapp/images/law.jpg');
                background-size: cover;
                color: #ffffff;
            }
        </style>
        """,
        unsafe_allow_html=True
    )

selected=option_menu(
        menu_title=None, #mandatory required
        options=["Litigation Strategy","Document Summarization"], 
        icons=["house","book"],#optional
        menu_icon=["cast"],
        default_index=0,
        orientation="horizontal",
                    styles={
                "container": {"padding": "0!important", "background-color": "#fafafa"},
                "icon": {"color": "orange", "font-size": "25px"},
                "nav-link": {
                    "font-size": "25px",
                    "text-align": "left",
                    "margin": "0px",
                    "--hover-color": "#eee",
                },
                "nav-link-selected": {"background-color": "green"},
            },
    )

# def main():
#     st.title("File Upload Example")
    
#     # File upload widget
#     uploaded_file = st.file_uploader("Choose a file", type=["csv", "txt", "xlsx"])

#     if uploaded_file is not None:
#         st.success("File successfully uploaded!")

#         # Display file details
#         file_details = {"Filename": uploaded_file.name, "FileType": uploaded_file.type, "FileSize": f"{uploaded_file.size / 1024:.2f} KB"}
#         st.write("### Uploaded File Details")
#         st.write(file_details)

#         # You can process the file as needed, for example, read a CSV file
#         # df = pd.read_csv(uploaded_file)
#         # st.write(df)   

import PyPDF2


def set_background_color(color):
    """
    Set the background color of the entire app.

    Parameters:
    - color (str): The background color in CSS format (e.g., 'lightblue').
    """
    page_bg_color = f"""
        <style>
            body {{
                background-color: {color};
            }}
        </style>
    """
    st.markdown(page_bg_color, unsafe_allow_html=True)

def read_pdf(file):
    pdf_reader = PyPDF2.PdfFileReader(file)
    text = ""
    for page_num in range(pdf_reader.numPages):
        page = pdf_reader.getPage(page_num)
        text += page.extractText()
    return text

def main():
    st.title("Upload your file")

    # File upload widgets
    uploaded_file = st.file_uploader("Upload a file", type=["pdf", "txt"])

    if uploaded_file is not None:
        st.success("File successfully uploaded!")

        # Display file details
        file_details = {"Filename": uploaded_file.name, "FileType": uploaded_file.type, "FileSize": f"{uploaded_file.size / 1024:.2f} KB"}
        st.write("### Uploaded File Details")
        st.write(file_details)

        # Read and display content based on file type
        if uploaded_file.type == "application/pdf":
            st.write("### PDF Content")
            pdf_text = read_pdf(uploaded_file)
            st.write(pdf_text)

        elif uploaded_file.type == "text/plain":
            st.write("### Text Content")
            text_content = uploaded_file.getvalue().decode("utf-8")
            st.write(text_content)

if selected=="Litigation Strategy":
    #st.title("Please upload your file we can help with the strategical points")
    main() 
if selected=="Document Summarization":
    #st.title(f"Please upload your file for summarization")
    main()

# # st.set_page_config(page_title="My first project",layout="wide", page_icon=":tada:")
# # # ---- HEADER SECTION ----
# # with st.container():
# #     st.subheader("Hi, I am Kodees :wave:")
# #     st.title("Streamlit option menu")
# #     st.write(
# #         "Instead of looking at my page why can't you just focus on your work."
# #     )
# #     st.write("[Learn More >](https://pythonandvba.com)")

import json

import requests  # pip install requests
#import streamlit as st  # pip install streamlit
from streamlit_lottie import st_lottie  # pip install streamlit-lottie

# GitHub: https://github.com/andfanilo/streamlit-lottie
# Lottie Files: https://lottiefiles.com/

def load_lottiefile(filepath: str):
    with open(filepath, "r") as f:
        return json.load(f)


def load_lottieurl(url: str):
    r = requests.get(url)
    if r.status_code != 200:
        return None
    return r.json()
    

lottie_coding = load_lottiefile("lottiefile.json")  # replace link to local lottie file
lottie_hello = load_lottieurl("https://assets9.lottiefiles.com/packages/lf20_M9p23l.json")

st_lottie(
    lottie_coding,
    speed=1,
    reverse=False,
    loop=True,
    quality="low", # medium ; high
    #renderer="svg", # canvas
    height=None,
    width=None,
    key=None,
)